module.exports = {
  content: ["./app/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        blackGold: "#090909",
        softBlack: "#111111",
        gold: "#C8A24A",
        lightGold: "#E8C97A",
        milk: "#F7F2E8"
      },
      fontFamily: {
        sans: ["Inter", "sans-serif"],
        display: ["Space Grotesk", "sans-serif"],
        serif: ["Cormorant Garamond", "serif"]
      }
    },
  },
  plugins: [],
};
